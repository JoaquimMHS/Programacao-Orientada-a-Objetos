public interface Forma2D extends Forma{

}
