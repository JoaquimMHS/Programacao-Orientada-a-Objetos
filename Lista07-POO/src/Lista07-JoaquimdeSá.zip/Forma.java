public interface Forma {
    double calcularArea();
    void imprimirDados();
}
