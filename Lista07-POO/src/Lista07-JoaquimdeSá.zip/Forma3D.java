public interface Forma3D extends Forma {
    double calcularVolume();
}
