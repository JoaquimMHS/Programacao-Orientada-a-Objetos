public interface Contato {
    String getNome();
    String getContato();
    String getTipo();
}
